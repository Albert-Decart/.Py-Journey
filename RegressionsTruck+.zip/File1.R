#library(broom)
#library(ggpubr)
library(naniar)
library(ggplot2)
library(dplyr)
library(readxl)
df0<-read_excel("C:\\Users\\Amin\\Downloads\\Amin Special Project\\Excel for R\\Trucks2.xlsx")
df<-as.data.frame(df0)
str(df)

#Deleting Irrelevant columns
df<-df %>% select(-one_of("ScriptNote","Reference","Status","AsmCategory",
                          "Currency"))
str(df)



#Creating New Variables -------------------------------------------------------------------------------------
df$age<-as.numeric(df$ReportYear-df$Year)+.5
df$FMVprice <- as.numeric(df$FMV_Low+df$FMV_High)*0.5
df$FMVlogprice<-log(df$FMVprice)
df$KmPerAge<-as.numeric(df$KmPerAge)
df$KmPerHour<-as.numeric(df$KmPerHour)
df$ReportAge<-2022-as.numeric(df$ReportYear)
df$MakeModel<-paste(df$Make,df$Model,sep='')
df$MakeEng<-paste(df$Make,df$Eng,sep='')
df$ReportYear<-as.character(df$ReportYear)

df$age2<-df$age*df$age
df$age3<-df$age2*df$age
df$lnAge<-log(df$age)

df$ageChar<-as.character(df$age)




#Removing NA Observations -----------------------------------------------------------------------------------
df <-df[complete.cases(df$age),]
df <-df[complete.cases(df$Make),]
df <-df[complete.cases(df$KM),]
df <-df[complete.cases(df$FMV_Low),]
df <-df[complete.cases(df$FMV_High),]


str(df)


#Normalizing Variables---------------------------------------------------------------------------------------

df$KmPerAgeN<-(df$KmPerAge-mean(df$KmPerAge))/100000
df$kmN<-(df$KM-mean(df$KM))/100000
#Mean Subtracting Variables -----------------------------------------------------------------------------------


#Data Description-------------------------------------------------------------------------------------
plot(df$FMVlogprice,df$KmPerAge)



#Selecting Observation for Regression-------------------------------------------------------------------------------------
df<-df %>% filter(FMVlogprice>9.8 & FMVlogprice<12.3 & age>0 & age<30 & KmPerAge<300000 & Category=="Conventional - Sleeper")

#Factoring Variables   -------------------------------------------------------------------------------------
attach(df)
table(Make)
Make<-factor(Make,c("International","Freightliner","Kenworth","Mack",'Peterbilt',"Volvo","Western Star"),labels=c("International","Freightliner","Kenworth","Mack",'Peterbilt',"Volvo","Western Star"))
contrasts(Make)
table(Axles_No)
detach(df)

#Regression Models-------------------------------------------------------------------------------------
df.lm<-lm( FMVlogprice~ age+age2+ReportYear+MakeModel +Axles_No+Eng+KmPerAge+Eng+Condition, data=df)
summary(df.lm)


#df<-df[df$Category=='Conventional - sleeper',]

df.lm<-lm( FMVlogprice~age+age2+age*KmPerAgeN+ReportYear+Make+Eng+AsmType+Axles_No+Category+Condition, data=df)
summary(df.lm)




uss<-.1
x<-seq(0,20,.01)
z<-exp(summary(df.lm)$coefficients['age',1]*x
       +summary(df.lm)$coefficients['age2',1]*(x^2)
       +summary(df.lm)$coefficients['KmPerAgeN',1]
       *uss+summary(df.lm)$coefficients['age:KmPerAgeN',1]*uss*log(x))

lines(x,z,col='blue')



dfOLV<-df[complete.cases(df$OLV_Low),]
dfOLV<-df[complete.cases(df$OLV_High),]
dfOLV$OLVprice <- as.numeric(dfOLV$OLV_Low+dfOLV$OLV_High)*0.5
dfOLV$OLVlogprice<-log(dfOLV$OLVprice)

dfFLV<-df[complete.cases(df$FLV_Low),]
dfFLV<-df[complete.cases(df$FLV_High),]
dfFLV$FLVprice <- as.numeric(dfFLV$FLV_Low+dfFLV$FLV_High)*0.5
dfFLV$FLVlogprice<-log(dfFLV$FLVprice)





uss<-0.1
x<-seq(agemin,agemax,.1)
z<-exp(summary(dfv.lm)$coefficients['age',1]
       *x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
plot (x,z,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z<-exp(summary(dfv.lm)$coefficients['age',1]
*x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
  lines(x,z)
}


