#library(broom)
#library(ggpubr)
library(naniar)
library(ggplot2)
library(dplyr)
library(readxl)
df0<-read_excel("C:\\Users\\Amin\\Downloads\\Amin Special Project\\Truck Plus\\Excel for R\\Skid Steer\\SkidSteer.xlsx")

df<-as.data.frame(df0)
str(df)

#Deleting Irrelevant columns
#df<-df %>% select(-one_of("ScriptNote","VerusID","Reference","Status","AsmCategory"))
str(df)

#Creating New Variables -------------------------------------------------------------------------------------

df$ReportYear<-df$RY

df$age<-as.numeric(df$ReportYear)-as.numeric(df$Year)
df$age2<-df$age*df$age
df$AgeChar<-as.character(df$age)
df$FMVlogprice<-log(as.numeric(df$ListedPriceAdj))


df$ReportAge<-2022-as.numeric(df$ReportYear)#+as.numeric(df$RMad/12)
df$MakeModel<-paste(df$Make,df$Model,sep='')



#Removing NA Observations -----------------------------------------------------------------------------------
df <-df[complete.cases(df$age),]
df <-df[complete.cases(df$Make),]
df <-df[complete.cases(df$SubCategory),]
df <-df[complete.cases(df$ListedPriceAdj),]
#df <-df[complete.cases(df$FMV_High),]





#Normalizing Variables---------------------------------------------------------------------------------------
df$Hours<-as.numeric(df$Hours)
df$EngineHP<-as.numeric(df$EngineHP)




#Data Description-------------------------------------------------------------------------------------
plot(df$FMVlogprice,df$age)



#Selecting Observation for Regression-------------------------------------------------------------------------------------
#df<-df %>% filter(FMVlogprice>4 & FMVlogprice<20.5 & age>=0 & age<30 & Description!="Super B")



df2<-df
#df2<-df2 %>% filter(SubCategory=="Deck Trailer")




df2.lm<-lm( FMVlogprice~AgeChar+MakeModel+AdType+Currency, data=df2)
summary(df2.lm)
#Regression Models-------------------------------------------------------------------------------------


df1<-df

df1.lm<-lm( FMVlogprice~age+age2+Type+Axle+Make, data=df1)
summary(df1.lm)

plot(df$FMVlogprice,df$age)
barplot(table(df$Make))



AGE<-2
RA<-0

Pf<-exp(11.92+summary(df.lm)$coefficients['age',1]
        *AGE+summary(df.lm)$coefficients['ReportAge',1]*RA)

dfOLV<-df[complete.cases(df$OLV_Low),]
dfOLV<-df[complete.cases(df$OLV_High),]
dfOLV$OLVprice <- as.numeric(dfOLV$OLV_Low+dfOLV$OLV_High)*0.5
dfOLV$OLVlogprice<-log(dfOLV$OLVprice)

dfFLV<-df[complete.cases(df$FLV_Low),]
dfFLV<-df[complete.cases(df$FLV_High),]
dfFLV$FLVprice <- as.numeric(dfFLV$FLV_Low+dfFLV$FLV_High)*0.5
dfFLV$FLVlogprice<-log(dfFLV$FLVprice)

df1<-df
dfOLV.lm<-lm( FMVlogprice~FLVlogprice, data=dfOLV)
summary(dfOLV.lm)

df0$Age<-df0$ReportYear - df0$Year +0.5
df0[2]<-as.numeric(df0[seq(1,201),2])
df0.lm<-lm( FMV_Low~ KM + Age  , data=df0)
summary(df0.lm)



df20$logprice <- log(df20$price)
df20$age<-2021.5 -df20$year
df20$age2<-df20$age * df20$age

df20$ageSqrt<-sqrt(df20$age)
df20$usage<-(df20$odometer/df20$age)/100000
df20$odometerk<-df20$odometer/100000

df20$usage2<-df20$usage*df20$usage


agemax<-31
agemin<- .5
dfv<-df20 %>% filter(price>999 & price<350000 & age>agemin & age<agemax & usage>0 & usage<1)
dfv1<-dfv
dfv2<-dfv
dfv3<-dfv
dfv4<-dfv


#Models:


dfv.lm<-lm( logprice~ manufacturer +age+age2+usage+usage*age+title_status+type, data=dfv)
summary(dfv.lm)

dfv1.lm<-lm( logprice~ manufacturer +age+usage+title_status+type, data=dfv1)
summary(dfv1.lm)

dfv2.lm<-lm( logprice~ manufacturer +age*odometerk +title_status+type, data=dfv2)
summary(dfv2.lm)

dfv3.lm<-lm( logprice~ manufacturer +age*usage +title_status+type, data=dfv3)
summary(dfv3.lm)

#dfv2.lm<-lm( logprice~ manufacturer+title_status +age2+usage*age+type, data=dfv2)
#summary(dfv2.lm)

#File1<- read_excel("C:\\Users\\Amin\\Downloads\\Book1.xlsx")
#File1[c("Year","FMV – Low")]

uss<-0.1
x<-seq(agemin,agemax,.1)
z<-exp(summary(dfv.lm)$coefficients['age',1]
       *x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
plot (x,z,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z<-exp(summary(dfv.lm)$coefficients['age',1]
         *x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
  lines(x,z)
}


uss<-0.1
x<-seq(agemin,agemax,.1)
z2<-summary(dfv.lm)$coefficients['age',1]+2*summary(dfv.lm)$coefficients['age2',1]*x+summary(dfv.lm)$coefficients['age:usage',1]*uss

plot (x,-z2,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z2<-summary(dfv.lm)$coefficients['age',1]+2*summary(dfv.lm)$coefficients['age2',1]*x+summary(dfv.lm)$coefficients['age:usage',1]*uss
  lines(x,-z2)
}


summary(dfv.lm)$coefficients['age',1]


uss<-0.1
x<-seq(agemin,agemax,.1)
z<-exp(-.1011*x+.00122*(x^2)-.188*uss-.261*uss*x)
plot (x,z,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z<-exp(-.1011*x+.00122*(x^2)-.188*uss-.261*uss*x)
  lines(x,z)
}