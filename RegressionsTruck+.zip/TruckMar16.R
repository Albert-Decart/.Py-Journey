#library(broom)
#library(ggpubr)
library(naniar)
library(ggplot2)
library(dplyr)
library(readxl)
df0<-read_excel("C:\\Users\\Amin\\Downloads\\Amin Special Project\\Truck Plus\\Excel for R\\Truck\\Truck2023Mar08.xlsx")

df00<-as.data.frame(df0)
df<-df00 %>% filter(ObservationType=="NewVersion")

df<-df[,seq(1,86)]
str(df)


#Removing NA Observations -----------------------------------------------------------------------------------
df <-df[complete.cases(df$AGE),]
df <-df[complete.cases(df$Make),]
df <-df[complete.cases(df$SubCategory),]
df <-df[complete.cases(df$FMV_Low),]
df <-df[complete.cases(df$FMV_High),]



#Creating New Variables -------------------------------------------------------------------------------------
df$age<-df$AGE
df$age2<-df$age*df$age
df$ageSq<-sqrt(df$age)
df$ageSqChar<-as.character(round(df$ageSq,1))
df$AgeChar<-as.character(round(df$age))




df$FMVprice <- (as.numeric(df$FMV_Low)+as.numeric(df$FMV_High))*0.5
df$FMVlogprice<-log(df$FMVprice)
AgeDiscout <- 0.06
AgeDiscout2 <- -0.0008
df$FMVAgeAdj <- df$FMVlogprice+(AgeDiscout*df$age +AgeDiscout2*df$age2)








df$Gr<-as.numeric(df$GVWR2)
df$MakeModel<-paste(df$Make,df$Model,sep='')
df$MakeModelEngine<-paste(df$Make,df$Model,df$EngineBrand,sep='')

#Normalizing Variables---------------------------------------------------------------------------------------
df$KM<-as.numeric(df$Km)/100000
df$KmChar<-as.character(round(df$KM,0))

df$Hp<-as.numeric(df$EngineHP)

df$Tr<-df$Transmission2
df$km2<-df$KM*df$KM

df$HR<-as.numeric(df$Hours)





#Data Description-------------------------------------------------------------------------------------




#Selecting Observation for Regression-------------------------------------------------------------------------------------
df1<-df %>% filter(FMVlogprice>4 & FMVlogprice<20.5 & age>=0 & age<14 & KM <20 & ObservationType!="New" )# & KMUsed!="0 & ReportYear==2019)
plot(df1$KM,df1$FMVAgeAdj)
plot(df1$KM,df1$FMVprice)


plot(df1$KM,df1$age)
df2<-df1



df001.lm<-lm( FMVAgeAdj~ReportDate+KM+km2+MakeModel+EngineBrand+Axles_No+Condition, data=df2)
summary(df001.lm)

Mat<-summary(df001.lm)
Mat_coef<-Mat$coefficients
write.csv(Mat_coef,file="TruckReg01.csv")

#MODEL I KM and AGE
df011.lm<-lm( FMVlogprice~ReportDate+KM+km2+abs(age)+age2+MakeModel+Hp+EngineBrand+Axles_No+Condition+AsmType+Certification, data=df2)
summary(df011.lm)

df012.lm<-lm( FMVlogprice~ReportDate+KM+km2+AgeChar+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df012.lm)

df013.lm<-lm( FMVlogprice~ReportDate+KM+km2+age*Make+age2+MakeModelEngine+Axles_No+AsmType+Condition+Sleeper+Certification+Wheels, data=df2)
summary(df013.lm)

#MODEL II  Only KM
df021.lm<-lm( FMVlogprice~ReportDate+KM+km2+MakeModelEngine+Axles_No+AsmType+Wheels+Sleeper+Condition+Certification, data=df2)
summary(df021.lm)

df022.lm<-lm( FMVlogprice~ReportDate+KM+km2+age2+KM*Make+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df022.lm)

df023.lm<-lm( FMVlogprice~ReportDate+KM+km2+age+KM*Make+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df023.lm)


#MODEL III  MSRP







