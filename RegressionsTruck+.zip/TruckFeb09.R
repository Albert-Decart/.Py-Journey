#library(broom)
#library(ggpubr)
library(naniar)
library(ggplot2)
library(dplyr)
library(readxl)
df0<-read_excel("C:\\Users\\Amin\\Downloads\\Amin Special Project\\Truck Plus\\Excel for R\\Truck\\Truck2023Mar08.xlsx")

df00<-as.data.frame(df0)
df<-df00 %>% filter(ObservationType=="NewVersion")

df<-df[,seq(1,86)]
str(df)

#Creating New Variables -------------------------------------------------------------------------------------
df$ED<-df$EffectiveDate

df$ReportYear<-substr(df$ED[],1,4)
df$ReportMonth<-substr(df$ED[],6,7)
df$ReportYM<-substr(df$ED[],1,7)
df$ReportYS<-paste(df$ReportYear,df$Season,sep='')




df$age<-as.numeric(df$ReportYear)-as.numeric(df$Year)
df$age2<-df$age*df$age
df$ageSq<-sqrt(df$age)
df$ageSqChar<-as.character(round(df$ageSq,1))
df$AgeChar<-as.character(round(df$age))


df <-df[complete.cases(df$FMV_Low),]
df <-df[complete.cases(df$FMV_High),]
df$FMVprice <- (as.numeric(df$FMV_Low)+as.numeric(df$FMV_High))*0.5
df$FMVlogprice<-log(df$FMVprice)

AgeDiscout <- 0.06
AgeDiscout2 <- -0.003
df$FMVAgeAdj <- df$FMVlogprice-(AgeDiscout*df$age +AgeDiscout2*df$age2)


df$Gr<-as.numeric(df$GVWR2)

df$ReportAge<-2022-as.numeric(df$ReportYear)
df$MakeModel<-paste(df$Make,df$Model,sep='')
df$MakeModelEngine<-paste(df$Make,df$Model,df$EngineBrand,sep='')



#Removing NA Observations -----------------------------------------------------------------------------------
df <-df[complete.cases(df$age),]
df <-df[complete.cases(df$Make),]
df <-df[complete.cases(df$SubCategory),]






#Normalizing Variables---------------------------------------------------------------------------------------
df$KM<-as.numeric(df$Km)/100000
df$KmChar<-as.character(round(df$KM,0))


df$NR<-log(as.numeric(df$NewReplacement))
df$OMSRP<-log(as.numeric(df$OriginalMSRP))
df$FMVtoOmsrp<-df$FMVprice/as.numeric(df$OriginalMSRP)
df$FMVtoNR<-df$FMVprice/as.numeric(df$NewReplacement)

df$Hp<-as.numeric(df$EngineHP)

df$Tr<-df$Transmission2
df$km2<-df$KM*df$KM

df$HR<-as.numeric(df$Hours)





#Data Description-------------------------------------------------------------------------------------




#Selecting Observation for Regression-------------------------------------------------------------------------------------
df1<-df %>% filter(FMVlogprice>4 & FMVlogprice<20.5 & age>=0 & age<14 )# & KMUsed!="0 & ReportYear==2019)
plot(df1$age,df1$FMVAgeAdj)
plot(df1$KM,df1$age)
df2<-df1
#df2<-df2 %>% filter(SubCategory=="Deck Trailer")

df001.lm<-lm( FMVlogprice~MakeModel,data=df2)
summary(df001.lm)


df001.lm<-lm( FMVAgeAdj~ReportYS+KM+km2+MakeModel+Hp+EngineBrand+Axles_No+Condition+AsmType, data=df2)
summary(df001.lm)

Mat<-summary(df001.lm)
Mat_coef<-Mat$coefficients
write.csv(Mat_coef,file="TruckReg01.csv")

#MODEL I KM and AGE
df011.lm<-lm( FMVlogprice~ReportYS+KM+km2+abs(age)+age2+MakeModel+Hp+EngineBrand+Axles_No+AsmType+Condition+Certification, data=df2)
summary(df011.lm)

df012.lm<-lm( FMVlogprice~ReportYS+KM+km2+AgeChar+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df012.lm)

df013.lm<-lm( FMVlogprice~ReportYS+KM+km2+age*Make+age2+MakeModelEngine+Axles_No+AsmType+Condition+Sleeper+Certification+Wheels, data=df2)
summary(df031.lm)

#MODEL II  Only KM
df021.lm<-lm( FMVlogprice~ReportYS+KM+km2+MakeModelEngine+Axles_No+AsmType+Wheels+Sleeper+Condition+Certification, data=df2)
summary(df021.lm)

df022.lm<-lm( FMVlogprice~ReportYS+KM+km2+age2+KM*Make+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df022.lm)

df023.lm<-lm( FMVlogprice~ReportYS+KM+km2+age+KM*Make+MakeModel+EngineBrand+Axles_No+AsmType+Sleeper+Condition+Certification, data=df2)
summary(df023.lm)


#MODEL III  MSRP



df20.lm<-lm( FMVtoNR~KM+km2+age+KM*Make+Condition, data=df2)
summary(df20.lm)

df30.lm<-lm( FMVtoOmsrp~KM+km2+age+KM*Make+Condition, data=df2)
summary(df30.lm)



#Regression Models-------------------------------------------------------------------------------------
x<-10
uss<-seq(0,20,.1)
z2<-exp(summary(df2.lm)$coefficients['age',1]*x+summary(df2.lm)$coefficients['KM',1]*uss+summary(df2.lm)$coefficients['km2',1]*(uss^2))

plot (uss,z2,type="b",col="blue")
for (i in seq(15)){
  x<-i
  z2<-exp(summary(df2.lm)$coefficients['age',1]*x+summary(df2.lm)$coefficients['KM',1]*uss+summary(df2.lm)$coefficients['km2',1]*(uss^2))
  lines(uss,z2)
}


uss<-2
x<-seq(0,20,.1)
z2<-exp(summary(df011.lm)$coefficients['age',1]*x+summary(df011.lm)$coefficients['age2',1]*(x^2)+summary(df011.lm)$coefficients['KM',1]*uss*x+summary(df011.lm)$coefficients['km2',1]*(uss^2)*x)

plot (x,z2,type="b",col="blue")
for (i in seq(3)){
  uss<-i
  z2<-exp(summary(df011.lm)$coefficients['age',1]*x+summary(df011.lm)$coefficients['age2',1]*(x^2)+summary(df011.lm)$coefficients['KM',1]*uss*x+summary(df011.lm)$coefficients['km2',1]*(uss^2)*x)
  lines(x,z2)
}



df1.lm<-lm( FMVlogprice~age+age2+Type+Axle+Make, data=df1)
summary(df1.lm)

plot(df$FMVlogprice,df$age)
barplot(table(df$Make))



AGE<-2
RA<-0

Pf<-exp(11.92+summary(df.lm)$coefficients['age',1]
        *AGE+summary(df.lm)$coefficients['ReportAge',1]*RA)

dfOLV<-df[complete.cases(df$OLV_Low),]
dfOLV<-df[complete.cases(df$OLV_High),]
dfOLV$OLVprice <- as.numeric(dfOLV$OLV_Low+dfOLV$OLV_High)*0.5
dfOLV$OLVlogprice<-log(dfOLV$OLVprice)

dfFLV<-df[complete.cases(df$FLV_Low),]
dfFLV<-df[complete.cases(df$FLV_High),]
dfFLV$FLVprice <- as.numeric(dfFLV$FLV_Low+dfFLV$FLV_High)*0.5
dfFLV$FLVlogprice<-log(dfFLV$FLVprice)

df1<-df
dfOLV.lm<-lm( FMVlogprice~FLVlogprice, data=dfOLV)
summary(dfOLV.lm)

df0$Age<-df0$ReportYear - df0$Year +0.5
df0[2]<-as.numeric(df0[seq(1,201),2])
df0.lm<-lm( FMV_Low~ KM + Age  , data=df0)
summary(df0.lm)



df20$logprice <- log(df20$price)
df20$age<-2021.5 -df20$year
df20$age2<-df20$age * df20$age

df20$ageSqrt<-sqrt(df20$age)
df20$usage<-(df20$odometer/df20$age)/100000
df20$odometerk<-df20$odometer/100000

df20$usage2<-df20$usage*df20$usage


agemax<-31
agemin<- .5
dfv<-df20 %>% filter(price>999 & price<350000 & age>agemin & age<agemax & usage>0 & usage<1)
dfv1<-dfv
dfv2<-dfv
dfv3<-dfv
dfv4<-dfv


#Models:


dfv.lm<-lm( logprice~ manufacturer +age+age2+usage+usage*age+title_status+type, data=dfv)
summary(dfv.lm)

dfv1.lm<-lm( logprice~ manufacturer +age+usage+title_status+type, data=dfv1)
summary(dfv1.lm)

dfv2.lm<-lm( logprice~ manufacturer +age*odometerk +title_status+type, data=dfv2)
summary(dfv2.lm)

dfv3.lm<-lm( logprice~ manufacturer +age*usage +title_status+type, data=dfv3)
summary(dfv3.lm)

#dfv2.lm<-lm( logprice~ manufacturer+title_status +age2+usage*age+type, data=dfv2)
#summary(dfv2.lm)

#File1<- read_excel("C:\\Users\\Amin\\Downloads\\Book1.xlsx")
#File1[c("Year","FMV – Low")]

uss<-0.1
x<-seq(agemin,agemax,.1)
z<-exp(summary(dfv.lm)$coefficients['age',1]
       *x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
plot (x,z,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z<-exp(summary(dfv.lm)$coefficients['age',1]
         *x+summary(dfv.lm)$coefficients['age2',1]*(x^2)+summary(dfv.lm)$coefficients['usage',1]*uss+summary(dfv.lm)$coefficients['age:usage',1]*uss*x)
  lines(x,z)
}


uss<-0.1
x<-seq(agemin,agemax,.1)
z2<-summary(dfv.lm)$coefficients['age',1]+2*summary(dfv.lm)$coefficients['age2',1]*x+summary(dfv.lm)$coefficients['age:usage',1]*uss

plot (x,-z2,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z2<-summary(dfv.lm)$coefficients['age',1]+2*summary(dfv.lm)$coefficients['age2',1]*x+summary(dfv.lm)$coefficients['age:usage',1]*uss
  lines(x,-z2)
}


summary(dfv.lm)$coefficients['age',1]


uss<-0.1
x<-seq(agemin,agemax,.1)
z<-exp(-.1011*x+.00122*(x^2)-.188*uss-.261*uss*x)
plot (x,z,type="b",col="blue")
for (i in seq(10)){
  uss<-i/40
  z<-exp(-.1011*x+.00122*(x^2)-.188*uss-.261*uss*x)
  lines(x,z)
}